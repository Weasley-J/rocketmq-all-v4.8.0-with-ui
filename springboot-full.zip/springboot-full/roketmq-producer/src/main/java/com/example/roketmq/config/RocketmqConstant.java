package com.example.roketmq.config;

/**
 * RocketMQ常量类
 * <li>生产者组名称常量</li>
 * <li>消费者分组常量</li>
 * <li>订阅话题常量</li>
 *
 * @author lwj
 */
public class RocketmqConstant {

    /**
     * 生产者组名称 Group name of producer
     */
    public static class ProducerGroup {
        public final static String Producer_ROCKETMQ_APP = "GID_ROCKETMQ_APP";
    }

    /**
     * 消费者分组常量
     */
    public static class ConsumerGroup {
        /**
         * sync topic group
         */
        public final static String SYNC_CONSUMER_GROUP = "my-consumer_sync-topic";
        /**
         * async topic group
         */
        public final static String ASYNC_CONSUMER_GROUP = "my-consumer_async-topic";
        /**
         * oneWay topic group
         */
        public final static String ONE_WAY_CONSUMER_GROUP = "my-consumer_oneWay-topic";
        /**
         * simple topic group
         */
        public final static String SIMPLE_CONSUMER_GROUP = "my-consumer_simple-topic";
    }

    /**
     * 订阅话题常量
     */
    public static class Topic {
        /**
         * sync topic
         */
        public final static String SYNC_TOPIC = "sync-topic";
        /**
         * async topic
         */
        public final static String ASYNC_TOPIC = "async-topic";
        /**
         * oneWay topic
         */
        public final static String ONE_WAY_TOPIC = "oneWay-topic";
        /**
         * simple-topic
         */
        public final static String SIMPLE_TOPIC = "simple-topic";
    }
}
