package com.example.roketmq.controller;

import com.example.roketmq.config.RocketmqConstant;
import org.apache.rocketmq.client.producer.SendCallback;
import org.apache.rocketmq.client.producer.SendResult;
import org.apache.rocketmq.common.message.Message;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 生产者
 */
@RestController
public class ProducerController {

    @Autowired
    private RocketMQTemplate rocketMQTemplate;

    /**
     * 同步消息
     */
    @GetMapping("/syncNews")
    public String syncNews() {
        Message message = new Message();
        message.setBody("同步消息".getBytes());
        SendResult sendResult = rocketMQTemplate.syncSend(RocketmqConstant.Topic.SYNC_TOPIC, message);
        // 同步消息发送成功会有一个返回值，我们可以用这个返回值进行判断和获取一些信息
        System.out.println(sendResult);
        return "success";
    }

    /**
     * 异步消息
     */
    @GetMapping("/asyncNews")
    public String asyncNews() {
        Message message = new Message();
        message.setBody("异步消息".getBytes());
        rocketMQTemplate.asyncSend(RocketmqConstant.Topic.ASYNC_TOPIC, message, new SendCallback() {
            @Override
            public void onSuccess(SendResult sendResult) {
                // 成功回调
            }

            @Override
            public void onException(Throwable throwable) {
                // 失败回调
            }
        });
        return "success";
    }

    /**
     * 单向消息
     */
    @GetMapping("/sendOneWay")
    public String sendOneWay() {
        Message message = new Message();
        message.setBody("单向消息".getBytes());
        rocketMQTemplate.sendOneWay(RocketmqConstant.Topic.ONE_WAY_TOPIC, message);
        return "success";
    }

    /**
     * 简单消息（字符串）
     */
    @GetMapping("/simpleTopic")
    public String simpleTopic() {
        rocketMQTemplate.convertAndSend(RocketmqConstant.Topic.SIMPLE_TOPIC, "搬运工把消息搬来了，简单消息(字符串)");
        return "success";
    }
}