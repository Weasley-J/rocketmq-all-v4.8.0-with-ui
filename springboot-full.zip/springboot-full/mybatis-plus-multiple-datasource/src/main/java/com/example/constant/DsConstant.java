package com.example.constant;

/**
 * 数据源常常量
 *
 * @author lwj
 */
public class DsConstant {
    /**
     * 主数据源
     */
    public static final String MASTER = "master";
    /**
     * 从数据源-1
     */
    public static final String SLAVE1 = "slave_1";
    /**
     * 从数据源-2
     */
    public static final String SLAVE2 = "slave_2";
}
