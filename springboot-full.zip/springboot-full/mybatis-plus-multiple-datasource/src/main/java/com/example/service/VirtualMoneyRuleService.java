package com.example.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.domain.VirtualMoneyRule;

import java.util.List;

/**
 * @author lwj
 */
public interface VirtualMoneyRuleService extends IService<VirtualMoneyRule> {
    /**
     * service不指定数据源时使用默认数据源
     *
     * @return
     */
    List<VirtualMoneyRule> listByDefault();

    /**
     * 使用主数据源查询列表
     *
     * @return
     */
    List<VirtualMoneyRule> listByMaster();

    /**
     * 使用从数据源1查询列表
     *
     * @return
     */
    List<VirtualMoneyRule> listBySlave1();

    /**
     * 使用从数据源2查询列表
     *
     * @return
     */
    List<VirtualMoneyRule> listBySlave2();
}
