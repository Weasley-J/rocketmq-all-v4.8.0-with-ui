package com.example.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 虚拟钱币规则表
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName(value = "virtual_money_rule")
public class VirtualMoneyRule implements Serializable {
    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.INPUT)
    private Long id;

    /**
     * 规则名称（如：xx商城的金币优惠规则，xx商城的积分规则，xx平台的云币优惠规则）
     */
    @TableField(value = "rule_name")
    private String ruleName;

    /**
     * 平台id: 0 无; 1 普通会员; 2 医生-优医邦; 3 药店（邦甸园）; 默认：0
     */
    @TableField(value = "platform_id")
    private Integer platformId;

    /**
     * 虚拟币来源（使用平台：1 商城、默认：1）
     */
    @TableField(value = "source_type")
    private Integer sourceType;

    /**
     * 虚拟币类型（0 积分  1 优医币，默认：0）
     */
    @TableField(value = "virtual_type")
    private Integer virtualType;

    /**
     * 虚拟币发放比例（发放平台的授予用户的比例）
     */
    @TableField(value = "grant_ratio")
    private BigDecimal grantRatio;

    /**
     * 虚拟币兑换比例（兑换成货币的比例）
     */
    @TableField(value = "exchange_ratio")
    private BigDecimal exchangeRatio;

    /**
     * 有效期开始时间
     */
    @TableField(value = "effect_start_time")
    private Date effectStartTime;

    /**
     * 有效期结束时间
     */
    @TableField(value = "effect_end_time")
    private Date effectEndTime;

    /**
     * 是否启用（0 禁用，1  启用, 默认：1）
     */
    @TableField(value = "`enable`")
    private Integer enable;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    private Date createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time")
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public static final String COL_ID = "id";

    public static final String COL_RULE_NAME = "rule_name";

    public static final String COL_PLATFORM_ID = "platform_id";

    public static final String COL_SOURCE_TYPE = "source_type";

    public static final String COL_VIRTUAL_TYPE = "virtual_type";

    public static final String COL_GRANT_RATIO = "grant_ratio";

    public static final String COL_EXCHANGE_RATIO = "exchange_ratio";

    public static final String COL_EFFECT_START_TIME = "effect_start_time";

    public static final String COL_EFFECT_END_TIME = "effect_end_time";

    public static final String COL_ENABLE = "enable";

    public static final String COL_CREATE_TIME = "create_time";

    public static final String COL_UPDATE_TIME = "update_time";
}