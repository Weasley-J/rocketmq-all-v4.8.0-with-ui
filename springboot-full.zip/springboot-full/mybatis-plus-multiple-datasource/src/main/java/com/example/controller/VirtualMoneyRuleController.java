package com.example.controller;

import com.example.domain.VirtualMoneyRule;
import com.example.service.VirtualMoneyRuleService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/api/ds")
public class VirtualMoneyRuleController {
    @Resource
    private VirtualMoneyRuleService virtualMoneyRuleService;

    @GetMapping("/default")
    public List<VirtualMoneyRule> listByDefault() {
        return virtualMoneyRuleService.listByDefault();
    }

    @GetMapping("/master")
    public List<VirtualMoneyRule> listByMaster() {
        return virtualMoneyRuleService.listByMaster();
    }

    @GetMapping("/slave1")
    public List<VirtualMoneyRule> listBySlave1() {
        return virtualMoneyRuleService.listBySlave1();
    }

    @GetMapping("/slave2")
    public List<VirtualMoneyRule> listBySlave2() {
        return virtualMoneyRuleService.listBySlave2();
    }
}

