package com.example.service.impl;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.constant.DsConstant;
import com.example.domain.VirtualMoneyRule;
import com.example.mapper.VirtualMoneyRuleMapper;
import com.example.service.VirtualMoneyRuleService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <b>多数据源切换测试</b>
 *
 * @author lwj
 */
@Service
public class VirtualMoneyRuleServiceImpl extends ServiceImpl<VirtualMoneyRuleMapper, VirtualMoneyRule> implements VirtualMoneyRuleService {

    /**
     * 不指定数据源时使用默认数据源
     *
     * @return 列表
     */
    @Override
    public List<VirtualMoneyRule> listByDefault() {
        return list();
    }

    /**
     * 使用主数据源查询列表
     *
     * @return 列表
     */
    @DS(DsConstant.MASTER)
    @Override
    public List<VirtualMoneyRule> listByMaster() {
        return list();
    }

    /**
     * 使用从数据源1查询列表
     *
     * @return 列表
     */
    @DS(DsConstant.SLAVE1)
    @Override
    public List<VirtualMoneyRule> listBySlave1() {
        return list();
    }

    /**
     * 使用从数据源2查询列表
     *
     * @return 列表
     */
    @DS(DsConstant.SLAVE2)
    @Override
    public List<VirtualMoneyRule> listBySlave2() {
        return list();
    }
}
