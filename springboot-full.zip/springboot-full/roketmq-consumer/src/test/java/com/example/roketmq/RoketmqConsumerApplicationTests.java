package com.example.roketmq;

import com.example.roketmq.contsant.RocketmqConstant;
import org.apache.rocketmq.spring.core.RocketMQTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

@SpringBootTest
class RoketmqConsumerApplicationTests {
    @Resource
    private RocketMQTemplate rocketMQTemplate;

    @Test
    void contextLoads() {
        for (int i = 0; i < 5; i++) {
            String payload = "我是马大哈！";
            rocketMQTemplate.convertAndSend(RocketmqConstant.Topic.SIMPLE_TOPIC, payload);
        }
    }

}
