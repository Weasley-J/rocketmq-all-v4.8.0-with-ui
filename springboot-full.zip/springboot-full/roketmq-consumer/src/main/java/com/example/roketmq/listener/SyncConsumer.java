package com.example.roketmq.listener;

import com.example.roketmq.contsant.RocketmqConstant;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

/**
 * 同步消费
 */
@Component
@RocketMQMessageListener(
        topic = RocketmqConstant.Topic.SYNC_TOPIC,
        consumerGroup = RocketmqConstant.ConsumerGroup.SYNC_CONSUMER_GROUP
)
public class SyncConsumer implements RocketMQListener<MessageExt> {

    @Override
    public void onMessage(MessageExt messageExt) {
        byte[] body = messageExt.getBody();
        String msg = new String(body);
        System.out.println(msg);
    }
}