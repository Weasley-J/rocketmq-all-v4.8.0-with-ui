package com.example.roketmq.listener;

import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;

@RocketMQMessageListener(
        topic = "bosscloud-mall-user-c_test",
        consumerGroup = "GID_bosscloud-mall-user-c"

)
public class BosscloudConsumer implements RocketMQListener<String> {
    @Override
    public void onMessage(String message) {
        System.out.printf("------- ACL StringConsumer received: %s \n", message);
    }
}