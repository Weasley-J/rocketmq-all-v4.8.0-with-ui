package com.example.roketmq.listener;

import com.example.roketmq.contsant.RocketmqConstant;
import org.apache.rocketmq.common.message.MessageExt;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

/**
 * 单向消息
 */
@Component
@RocketMQMessageListener(
        topic =  RocketmqConstant.Topic.ONE_WAY_TOPIC,
        consumerGroup = RocketmqConstant.ConsumerGroup.ONE_WAY_CONSUMER_GROUP
)
public class OneWayConsumer implements RocketMQListener<MessageExt> {

    @Override
    public void onMessage(MessageExt messageExt) {
        byte[] body = messageExt.getBody();
        String msg = new String(body);
        System.out.println(msg);
    }
}