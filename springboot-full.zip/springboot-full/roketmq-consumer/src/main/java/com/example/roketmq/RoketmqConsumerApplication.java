package com.example.roketmq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoketmqConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(RoketmqConsumerApplication.class, args);
    }
}
