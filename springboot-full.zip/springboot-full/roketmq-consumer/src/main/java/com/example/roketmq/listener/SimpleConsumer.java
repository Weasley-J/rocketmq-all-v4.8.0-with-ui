package com.example.roketmq.listener;

import com.example.roketmq.contsant.RocketmqConstant;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.spring.annotation.RocketMQMessageListener;
import org.apache.rocketmq.spring.core.RocketMQListener;
import org.springframework.stereotype.Component;

/**
 * 同步消费
 */
@Slf4j
@Component
@RocketMQMessageListener(
        topic =  RocketmqConstant.Topic.SIMPLE_TOPIC,
        consumerGroup = RocketmqConstant.ConsumerGroup.SIMPLE_CONSUMER_GROUP
)
public class SimpleConsumer implements RocketMQListener<String> {

    @Override
    public void onMessage(String msg) {
        log.info("消息来了:{}", msg);
    }
}