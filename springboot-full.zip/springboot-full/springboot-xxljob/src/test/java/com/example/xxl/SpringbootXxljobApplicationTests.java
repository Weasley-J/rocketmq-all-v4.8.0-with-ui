package com.example.xxl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootXxljobApplicationTests {

    @Test
    void contextLoads() {
    }

}
