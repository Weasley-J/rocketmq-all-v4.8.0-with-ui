package com.example.xxl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * xxl-job示例
 *
 * @author lwj
 */
@SpringBootApplication
public class SpringbootXxljobApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpringbootXxljobApplication.class, args);
    }
}
