package com.example.xxl.config;

import cn.hutool.json.JSONUtil;
import com.xxl.job.core.executor.impl.XxlJobSpringExecutor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.Serializable;
import java.util.List;

/**
 * xxl-job配置类
 * <p>
 *
 * @author lwj
 * @date 2021年4月28日11:23:37
 */
@Slf4j
@Configuration
public class XxlJobConfig {

    @Resource
    private XxlJobProperties xxlJobProperties;

    @Bean
    public XxlJobSpringExecutor xxlJobSpringExecutor() {
        System.err.println("开始初始化xxl-job配置，元数据json：" + JSONUtil.toJsonPrettyStr(xxlJobProperties));
        XxlJobSpringExecutor executor = new XxlJobSpringExecutor();
        executor.setAdminAddresses(xxlJobProperties.getAdmin().getAddresses());
        executor.setAccessToken(xxlJobProperties.getAccessToken());
        executor.setAppname(xxlJobProperties.getExecutor().getAppName());
        executor.setAddress(xxlJobProperties.getExecutor().getAddress());
        executor.setIp(xxlJobProperties.getExecutor().getIp());
        executor.setPort(xxlJobProperties.getExecutor().getPort());
        executor.setLogPath(xxlJobProperties.getExecutor().getLogPath());
        executor.setLogRetentionDays(xxlJobProperties.getExecutor().getLogRetentionDays());
        return executor;
    }

    /**
     * xxl-job配置元数据
     *
     * @author lwj
     * @date 2021年4月28日11:42:05
     */
    @Data
    @Component
    @ConfigurationProperties(prefix = "xxl.job")
    public static class XxlJobProperties implements Serializable {
        private static final long serialVersionUID = 1L;
        /**
         * xxl-job admin address list, such as "http://address" or "http://address01,http://address02"
         */
        private AdminAddress admin;
        /**
         * xxl-job, access token
         */
        private String accessToken;
        /**
         * xxl-job执行器
         */
        private Executor executor;

        /**
         * xxl-job 调度中心地址
         */
        @Data
        public static class AdminAddress implements Serializable {
            private static final long serialVersionUID = 1L;
            /**
             * xxl-job admin address list, such as "http://address" or "http://address01,http://address02"
             */
            private List<String> addresses;

            public String getAddresses() {
                return String.join(",", addresses);
            }
        }

        /**
         * 执行器配置元数据
         */
        @Data
        public static class Executor implements Serializable {
            private static final long serialVersionUID = 1L;
            /**
             * xxl-job executor app name
             */
            private String appName;
            /**
             * xxl-job executor registry-address: default use address to registry , otherwise use ip:port if address is null
             */
            private String address;
            /**
             * xxl-job executor server-info
             */
            private String ip = "localhost";
            /**
             * xxl-job executor port, default: 9999
             */
            private Integer port = 9999;
            /**
             * xxl-job executor log-path, default: /data/applogs/xxl-job/jobhandler
             */
            private String logPath = "/data/applogs/xxl-job/jobhandler";
            /**
             * xxl-job executor log-retention-days, default: 30
             */
            private Integer logRetentionDays = 30;
        }
    }
}