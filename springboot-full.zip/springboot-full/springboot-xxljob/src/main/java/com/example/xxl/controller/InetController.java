package com.example.xxl.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.commons.util.InetUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 获取ipController
 * <p>
 *
 * @author lwj
 * @version 1.0
 * @date 2021-04-28 11:10
 */
@Slf4j
@RestController
@RequestMapping("/ip")
public class InetController {

    @Resource
    private InetUtils inetUtils;

    @GetMapping("address")
    public String getIp() {
        return inetUtils.findFirstNonLoopbackHostInfo().getIpAddress();
    }
}
