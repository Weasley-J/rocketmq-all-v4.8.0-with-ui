package com.example.xxl.job;

import cn.hutool.core.date.DateUtil;
import com.xxl.job.core.biz.model.ReturnT;
import com.xxl.job.core.handler.annotation.XxlJob;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;


/**
 * XxlJob开发示例
 *
 * @author lwj
 */
@Slf4j
@Component
public class SampleXxlJobDemo {

    @XxlJob(value = "testJobHandler", init = "init", destroy = "destroy")
    public ReturnT<String> testJobHandler(String param) throws Exception {
        System.err.println("沙雕XXL-JOB,要我手动添加执行器-" + DateUtil.now());
        return ReturnT.SUCCESS;
    }

    public void init() {
        System.err.println("开始了...");
    }

    public void destroy() {
        System.err.println("结束了...");
    }
}